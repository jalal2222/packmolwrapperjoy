#PackmolWrapper
Generate [Packmol](http://www.ime.unicamp.br/~martinez/packmol/) input files using a Python class
